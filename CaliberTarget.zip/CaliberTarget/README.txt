- Need to install XAPK Installer to install .xapk server file
- Install "TrebEdit" to edit/adjust html file locally on tablet


https://play.google.com/store/apps/details?id=com.phlox.simpleserver&hl=en_CA

Enable "Render Folder Content Pages" (Requires Android system 14 or under)
Enable "AutoStart on Boot"

Pin the app to help prevent users exiting out

Delete unused apps and features from tablet